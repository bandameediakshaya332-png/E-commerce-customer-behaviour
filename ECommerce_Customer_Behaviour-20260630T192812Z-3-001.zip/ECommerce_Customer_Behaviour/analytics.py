from database import get_all_customers



def total_customers():

    customers = get_all_customers()

    return len(customers)



def total_revenue():

    customers = get_all_customers()

    revenue = sum(customer[7] * customer[8] for customer in customers)

    return revenue



def average_purchase():

    customers = get_all_customers()

    if not customers:
        return 0

    revenue = total_revenue()

    return round(revenue / len(customers), 2)



def category_sales():

    customers = get_all_customers()

    category = {}

    for customer in customers:

        category_name = customer[6]

        amount = customer[7] * customer[8]

        category[category_name] = category.get(category_name, 0) + amount

    return category



def payment_statistics():

    customers = get_all_customers()

    payment = {}

    for customer in customers:

        method = customer[10]

        payment[method] = payment.get(method, 0) + 1

    return payment



def top_customer():

    customers = get_all_customers()

    if not customers:
        return None

    highest = max(
        customers,
        key=lambda customer: customer[7] * customer[8]
    )

    return {
        "Customer ID": highest[0],
        "Name": highest[1],
        "Amount": highest[7] * highest[8]
    }



def top_category():

    sales = category_sales()

    if not sales:
        return None

    return max(sales, key=sales.get)



def dashboard_summary():

    return {
        "Total Customers": total_customers(),
        "Total Revenue": total_revenue(),
        "Average Purchase": average_purchase(),
        "Top Category": top_category(),
        "Top Customer": top_customer()
    }