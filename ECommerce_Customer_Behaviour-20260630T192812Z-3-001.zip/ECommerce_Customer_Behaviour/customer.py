class Customer:

    def __init__(self,
                 customer_id,
                 name,
                 age,
                 gender,
                 city,
                 product,
                 category,
                 quantity,
                 price,
                 purchase_date,
                 payment_method):

        self.customer_id = customer_id
        self.name = name
        self.age = age
        self.gender = gender
        self.city = city
        self.product = product
        self.category = category
        self.quantity = quantity
        self.price = price
        self.purchase_date = purchase_date
        self.payment_method = payment_method

    def total_price(self):
        return self.quantity * self.price

    def display(self):
        print("-" * 60)
        print("Customer ID :", self.customer_id)
        print("Name        :", self.name)
        print("Age         :", self.age)
        print("Gender      :", self.gender)
        print("City        :", self.city)
        print("Product     :", self.product)
        print("Category    :", self.category)
        print("Quantity    :", self.quantity)
        print("Price       :", self.price)
        print("Total       :", self.total_price())
        print("Purchase    :", self.purchase_date)
        print("Payment     :", self.payment_method)