import pandas as pd
import os

from database import insert_customer, clear_database



def import_csv(file):

    if not os.path.exists(file):
        raise FileNotFoundError(f"{file} not found.")

    clear_database()

    df = pd.read_csv(file)

    for row in df.itertuples(index=False):

        customer = (
            row.CustomerID,
            row.Name,
            row.Age,
            row.Gender,
            row.City,
            row.Product,
            row.Category,
            row.Quantity,
            row.Price,
            row.PurchaseDate,
            row.PaymentMethod
        )

        insert_customer(customer)

    return len(df)



def display_dataframe(file):

    if not os.path.exists(file):
        print("CSV File Not Found")
        return

    df = pd.read_csv(file)

    print(df)



def total_records(file):

    if not os.path.exists(file):
        return 0

    df = pd.read_csv(file)

    return len(df)



def preview_data(file, rows=5):

    if not os.path.exists(file):
        print("CSV File Not Found")
        return

    df = pd.read_csv(file)

    print(df.head(rows))