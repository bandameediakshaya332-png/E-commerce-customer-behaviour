import tkinter as tk
from tkinter import ttk, messagebox

from database import *
from data_import import *

create_database()




def import_data():
    try:
        import_csv("data/customers.csv")
        messagebox.showinfo("Success", "Customer data imported successfully!")
        load_customers()
    except Exception as e:
        messagebox.showerror("Error", str(e))


def load_customers():

    for row in tree.get_children():
        tree.delete(row)

    customers = get_all_customers()

    for customer in customers:
        tree.insert("", tk.END, values=customer)


def delete_data():

    cid = entry_id.get()

    if cid == "":
        messagebox.showwarning("Warning", "Enter Customer ID")
        return

    delete_customer(int(cid))

    messagebox.showinfo("Success", "Customer Deleted")

    load_customers()


def update_data():

    cid = entry_id.get()

    quantity = entry_quantity.get()

    price = entry_price.get()

    if cid == "" or quantity == "" or price == "":
        messagebox.showwarning("Warning", "Fill all fields")
        return

    update_customer(
        int(cid),
        int(quantity),
        float(price)
    )

    messagebox.showinfo("Success", "Customer Updated")

    load_customers()

def clear_fields():

    entry_id.delete(0, tk.END)
    entry_name.delete(0, tk.END)
    entry_age.delete(0, tk.END)
    entry_city.delete(0, tk.END)
    entry_product.delete(0, tk.END)
    entry_category.delete(0, tk.END)
    entry_quantity.delete(0, tk.END)
    entry_price.delete(0, tk.END)
    entry_date.delete(0, tk.END)

    gender.set("")
    payment.set("")


def add_customer():

    

    try:

        customer = (

            int(entry_id.get()),
            entry_name.get(),
            int(entry_age.get()),
            gender.get(),
            entry_city.get(),
            entry_product.get(),
            entry_category.get(),
            int(entry_quantity.get()),
            float(entry_price.get()),
            entry_date.get(),
            payment.get()

        )

        insert_customer(customer)

        load_customers()

        messagebox.showinfo(
            "Success",
            "Customer Added Successfully"
        )

        clear_fields()

    except Exception as e:

        messagebox.showerror(
            "Error",
            str(e)
        )


root = tk.Tk()

root.title("E-Commerce Customer Behaviour Analysis")

root.geometry("1100x600")

root.configure(bg="white")


title = tk.Label(
    root,
    text="E-Commerce Customer Behaviour Analysis",
    font=("Arial", 18, "bold"),
    bg="navy",
    fg="white",
    pady=10
)

title.pack(fill="x")


frame = tk.Frame(root, bg="white")

frame.pack(pady=20)


btn_frame = tk.Frame(root)

btn_frame.pack(pady=10)


tk.Label(frame, text="Customer ID").grid(row=0, column=0, padx=5, pady=5)
entry_id = tk.Entry(frame)
entry_id.grid(row=0, column=1)

tk.Label(frame, text="Name").grid(row=0, column=2, padx=5, pady=5)
entry_name = tk.Entry(frame)
entry_name.grid(row=0, column=3)

tk.Label(frame, text="Age").grid(row=1, column=0, padx=5, pady=5)
entry_age = tk.Entry(frame)
entry_age.grid(row=1, column=1)

tk.Label(frame, text="Gender").grid(row=1, column=2, padx=5, pady=5)
gender = ttk.Combobox(frame, values=["Male", "Female"], state="readonly")
gender.grid(row=1, column=3)

tk.Label(frame, text="City").grid(row=2, column=0, padx=5, pady=5)
entry_city = tk.Entry(frame)
entry_city.grid(row=2, column=1)

tk.Label(frame, text="Product").grid(row=2, column=2, padx=5, pady=5)
entry_product = tk.Entry(frame)
entry_product.grid(row=2, column=3)

tk.Label(frame, text="Category").grid(row=3, column=0, padx=5, pady=5)
entry_category = tk.Entry(frame)
entry_category.grid(row=3, column=1)

tk.Label(frame, text="Quantity").grid(row=3, column=2, padx=5, pady=5)
entry_quantity = tk.Entry(frame)
entry_quantity.grid(row=3, column=3)

tk.Label(frame, text="Price").grid(row=4, column=0, padx=5, pady=5)
entry_price = tk.Entry(frame)
entry_price.grid(row=4, column=1)

tk.Label(frame, text="Purchase Date").grid(row=4, column=2, padx=5, pady=5)
entry_date = tk.Entry(frame)
entry_date.grid(row=4, column=3)

payment = tk.StringVar()
payment.set("Cash")

tk.Label(frame, text="Payment").grid(row=5, column=0, padx=5, pady=5)

tk.Radiobutton(
    frame,
    text="Cash",
    variable=payment,
    value="Cash",
    bg="white"
).grid(row=5, column=1, sticky="w")

tk.Radiobutton(
    frame,
    text="Card",
    variable=payment,
    value="Card",
    bg="white"
).grid(row=5, column=2, sticky="w")

tk.Radiobutton(
    frame,
    text="UPI",
    variable=payment,
    value="UPI",
    bg="white"
).grid(row=5, column=3, sticky="w")


tk.Button(
    btn_frame,
    text="Import CSV",
    bg="green",
    fg="white",
    width=15,
    command=import_data
).grid(row=0, column=2, padx=10)

tk.Button(
    btn_frame,
    text="Add Customer",
    bg="green",
    fg="white",
    width=15,
    command=add_customer
).grid(row=0, column=0, padx=10)


tk.Button(
    btn_frame,
    text="Display",
    bg="blue",
    fg="white",
    width=15,
    command=load_customers
).grid(row=0, column=2, padx=10)


tk.Button(
    btn_frame,
    text="Update",
    bg="orange",
    fg="white",
    width=15,
    command=update_data
).grid(row=0, column=3, padx=10)


tk.Button(
    btn_frame,
    text="Delete",
    bg="red",
    fg="white",
    width=15,
    command=delete_data
).grid(row=0, column=4, padx=10)


columns = (
    "ID",
    "Name",
    "Age",
    "Gender",
    "City",
    "Product",
    "Category",
    "Quantity",
    "Price",
    "Purchase Date",
    "Payment"
)

tree = ttk.Treeview(root, columns=columns, show="headings")

for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=100)

tree.pack(fill="both", expand=True, padx=20, pady=20)

load_customers()

root.mainloop()