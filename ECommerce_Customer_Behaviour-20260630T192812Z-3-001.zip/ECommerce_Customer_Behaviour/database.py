import sqlite3
import os

DB_FOLDER = "database"
DB_NAME = os.path.join(DB_FOLDER, "ecommerce.db")


def get_connection():

    os.makedirs(DB_FOLDER, exist_ok=True)

    return sqlite3.connect(DB_NAME)


def create_database():

    with get_connection() as conn:

        cursor = conn.cursor()

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers(

            customer_id INTEGER PRIMARY KEY,

            name TEXT NOT NULL,

            age INTEGER,

            gender TEXT,

            city TEXT,

            product TEXT,

            category TEXT,

            quantity INTEGER,

            price REAL,

            purchase_date TEXT,

            payment_method TEXT

        )
        """)

        conn.commit()


def insert_customer(data):

    with get_connection() as conn:

        cursor = conn.cursor()

        cursor.execute("""
        INSERT OR REPLACE INTO customers
        VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """, data)

        conn.commit()


def get_all_customers():

    with get_connection() as conn:

        cursor = conn.cursor()

        cursor.execute("""
        SELECT * FROM customers
        ORDER BY customer_id
        """)

        return cursor.fetchall()


def search_customer(customer_id):

    with get_connection() as conn:

        cursor = conn.cursor()

        cursor.execute(
            "SELECT * FROM customers WHERE customer_id=?",
            (customer_id,)
        )

        return cursor.fetchone()


def update_customer(customer_id,
                    quantity,
                    price):

    with get_connection() as conn:

        cursor = conn.cursor()

        cursor.execute("""

        UPDATE customers

        SET quantity=?,

            price=?

        WHERE customer_id=?

        """, (quantity,
              price,
              customer_id))

        conn.commit()


def delete_customer(customer_id):

    with get_connection() as conn:

        cursor = conn.cursor()

        cursor.execute(
            "DELETE FROM customers WHERE customer_id=?",
            (customer_id,)
        )

        conn.commit()


def clear_database():

    with get_connection() as conn:

        cursor = conn.cursor()

        cursor.execute("DELETE FROM customers")

        conn.commit()


def customer_exists(customer_id):

    with get_connection() as conn:

        cursor = conn.cursor()

        cursor.execute(
            "SELECT COUNT(*) FROM customers WHERE customer_id=?",
            (customer_id,)
        )

        return cursor.fetchone()[0] > 0