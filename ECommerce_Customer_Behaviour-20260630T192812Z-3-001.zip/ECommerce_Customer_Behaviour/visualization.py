import matplotlib.pyplot as plt
from database import get_all_customers
from collections import defaultdict



def revenue_chart():

    customers = get_all_customers()

    if not customers:
        print("No Data Available")
        return

    category = {}

    for customer in customers:

        cat = customer[6]
        amount = customer[7] * customer[8]

        category[cat] = category.get(cat, 0) + amount

    plt.figure(figsize=(8,5))

    plt.bar(category.keys(), category.values())

    plt.title("Revenue by Category")

    plt.xlabel("Category")

    plt.ylabel("Revenue (₹)")

    plt.grid(axis="y")

    plt.tight_layout()

    plt.show()



def payment_chart():

    customers = get_all_customers()

    if not customers:
        print("No Data Available")
        return

    payment = {}

    for customer in customers:

        method = customer[10]

        payment[method] = payment.get(method,0)+1

    plt.figure(figsize=(6,6))

    plt.pie(
        payment.values(),
        labels=payment.keys(),
        autopct="%1.1f%%",
        startangle=90
    )

    plt.title("Payment Method Distribution")

    plt.tight_layout()

    plt.show()



def city_chart():

    customers = get_all_customers()

    if not customers:
        print("No Data Available")
        return

    city = {}

    for customer in customers:

        c = customer[4]

        city[c] = city.get(c,0)+1

    plt.figure(figsize=(8,5))

    plt.bar(city.keys(), city.values())

    plt.title("Customers by City")

    plt.xlabel("City")

    plt.ylabel("Customers")

    plt.xticks(rotation=20)

    plt.grid(axis="y")

    plt.tight_layout()

    plt.show()



def monthly_sales_chart():

    customers = get_all_customers()

    if not customers:
        print("No Data Available")
        return

    monthly = defaultdict(float)

    for customer in customers:

        month = customer[9][:7]     

        amount = customer[7] * customer[8]

        monthly[month] += amount

    plt.figure(figsize=(8,5))

    plt.plot(
        list(monthly.keys()),
        list(monthly.values()),
        marker="o"
    )

    plt.title("Monthly Sales")

    plt.xlabel("Month")

    plt.ylabel("Revenue (₹)")

    plt.grid(True)

    plt.tight_layout()

    plt.show()



def product_sales_chart():

    customers = get_all_customers()

    if not customers:
        print("No Data Available")
        return

    product = {}

    for customer in customers:

        p = customer[5]

        product[p] = product.get(p,0)+customer[7]

    plt.figure(figsize=(9,5))

    plt.bar(product.keys(), product.values())

    plt.title("Product Sales")

    plt.xlabel("Products")

    plt.ylabel("Quantity Sold")

    plt.xticks(rotation=30)

    plt.grid(axis="y")

    plt.tight_layout()

    plt.show()