# E-Commerce Customer Behaviour Analysis

## Mini Project

### Project Description

The **E-Commerce Customer Behaviour Analysis** project is a Python-based desktop application developed using **Tkinter**, **SQLite**, **Pandas**, **Matplotlib**, and **Scikit-learn**.

The application helps analyze customer purchasing behavior by storing customer details, performing sales analytics, generating charts, and predicting customer purchasing patterns using Machine Learning.

This project is designed as a **Mini Project** for Computer Science and Engineering students to demonstrate the practical implementation of Python programming, database management, data analytics, and machine learning.

---

## Objectives

- Develop a GUI-based desktop application.
- Store customer information using SQLite.
- Analyze customer purchasing behaviour.
- Generate graphical reports.
- Predict future customer purchasing behaviour.
- Improve business decision-making through analytics.

---

## Technologies Used

- Python 3.x
- Tkinter
- SQLite
- Pandas
- NumPy
- Matplotlib
- Scikit-learn

---

## Project Modules

### 1. Database Module

- Create Database
- Insert Customer
- Update Customer
- Delete Customer
- Search Customer
- Display Customer

### 2. Customer Management Module

- Add Customer
- Update Customer
- Delete Customer
- Search Customer
- Display Customer Information

### 3. Data Import Module

- Import CSV Dataset
- Load Customer Data
- Preview Dataset

### 4. Analytics Module

- Total Customers
- Total Revenue
- Average Purchase
- Category-wise Sales
- Payment Statistics
- Top Customer

### 5. Visualization Module

- Revenue Bar Chart
- Payment Pie Chart
- Customer City Chart
- Product Sales Chart
- Monthly Sales Chart

### 6. Machine Learning Module

- Decision Tree Classifier
- Customer Behaviour Prediction
- Prediction Accuracy

---

## Features

- GUI Application
- SQLite Database
- Customer Management
- CSV Data Import
- Revenue Analysis
- Sales Analytics
- Data Visualization
- Machine Learning Prediction
- Easy-to-use Interface

---

## Folder Structure

```
ECommerceCustomerBehaviour/
│
├── main.py
├── database.py
├── customer.py
├── data_import.py
├── analytics.py
├── visualization.py
├── prediction.py
├── requirements.txt
├── README.md
│
├── database/
│   └── ecommerce.db
│
├── data/
│   └── customers.csv
│
├── reports/
│
└── assets/
```

---

## Installation

Install the required libraries:

```bash
pip install -r requirements.txt
```

---

## Run the Project

```bash
python main.py
```

---

## Sample Dataset

The dataset is stored in:

```
data/customers.csv
```

---

## Future Enhancements

- User Login System
- Report Generation (PDF & Excel)
- Customer Search Filters
- Dashboard Analytics
- Cloud Database Integration
- Deep Learning Prediction
- Email Notifications

---

## Advantages

- User-friendly GUI
- Fast data processing
- Easy customer management
- Data visualization using charts
- Machine learning integration
- Simple database management

---

## Applications

- Online Shopping Platforms
- Retail Stores
- Sales Analysis
- Customer Relationship Management (CRM)
- Business Intelligence

---

## Conclusion

The **E-Commerce Customer Behaviour Analysis** project provides an effective solution for storing, managing, analyzing, and predicting customer purchasing behaviour. The project combines database management, GUI development, analytics, visualization, and machine learning into a single desktop application, making it a useful academic mini project and a foundation for future business analytics applications.

---
# Developer

Candidate Name: B.Akshaya

Intern ID: CITS2690

B.Tech – Computer Science and Engineering

Data Science Internship Mini Project