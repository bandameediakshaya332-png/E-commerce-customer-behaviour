import os
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score


CSV_FILE = "data/customers.csv"


def train_model():

    if not os.path.exists(CSV_FILE):
        raise FileNotFoundError("customers.csv not found.")

    df = pd.read_csv(CSV_FILE)

    required_columns = [
        "Age",
        "Gender",
        "Price",
        "PaymentMethod",
        "Quantity"
    ]

    for column in required_columns:
        if column not in df.columns:
            raise ValueError(f"Missing column: {column}")

    df["Gender"] = df["Gender"].map({
        "Male": 0,
        "Female": 1
    })

    df["PaymentMethod"] = df["PaymentMethod"].map({
        "Cash": 0,
        "Card": 1,
        "UPI": 2
    })

    df = df.dropna()

    df["Target"] = (df["Quantity"] > 1).astype(int)

    X = df[["Age", "Gender", "Price", "PaymentMethod"]]

    y = df["Target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.30,
        random_state=42
    )

    model = DecisionTreeClassifier(random_state=42)

    model.fit(X_train, y_train)

    predictions = model.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)

    return model, round(accuracy * 100, 2)


def customer_prediction():

    model, accuracy = train_model()

    return {
        "Algorithm": "Decision Tree",
        "Accuracy": accuracy
    }


def predict_new_customer(age, gender, price, payment_method):

    model, _ = train_model()

    gender = {
        "Male": 0,
        "Female": 1
    }.get(gender, 0)

    payment_method = {
        "Cash": 0,
        "Card": 1,
        "UPI": 2
    }.get(payment_method, 0)

    prediction = model.predict([
        [age, gender, price, payment_method]
    ])

    if prediction[0] == 1:
        return "Likely to Purchase Again"

    return "Less Likely to Purchase Again"